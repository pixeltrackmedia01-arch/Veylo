import type { MetadataRoute } from "next";
import { getSiteUrl } from "@/lib/env";

export default function robots(): MetadataRoute.Robots {
  const base = getSiteUrl();
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/dashboard", "/admin", "/dealer", "/api/", "/auth/", "/reset-password"] }],
    sitemap: `${base}/sitemap.xml`,
  };
}
